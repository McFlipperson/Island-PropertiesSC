import agent from "./agent";
import property from "./property";

export const schemaTypes = [property, agent];
